<table border="0" cellspacing="0" cellpadding="0" 
style="width:780px; height:58px;">
	<tr>
		<td>
			<a href="http://w3schools.com">
				<img src="images/footer.gif" border="0" />
			</a>
		</td>
	</tr>
</table>