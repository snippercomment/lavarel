<table border="0" cellpadding = "0" cellspacing = "0" 
style="width:780px; height:102px; background-image:url(images/topbanner.gif);">
	<tr style="height:32px;">
		<!-- <td colspan="2" style="height:102px;"> -->
		<!-- </td> -->
		<td>
			<!-- language -->
			<table border="0" cellpadding="0" cellspading="0" style="width:780px; height:32px;">
				<tr>
					<td style="width:615px; "></td>
					<td style="width:52px; text-align:center">
					<a href="#" class="lang">VN</a>
				</td>
					<td style="width:62px;text-align:center"><a href="#" class="lang">EN</a></td>
					<td style="width:48px;text-align:center"><a href="#" class="lang">CN</a></td>
				</tr>
			</table>
		</td>
	</tr>
	<tr style="height: 46px;">
		<td>
			
		</td>
    </tr>
	<tr style="height: 24px;">
			<td>
			<table border="0" cellpadding="0" cellspading="0" style="width:780px; height:32px;">
				<tr>
					<td style="width:170px; "></td>
					<td style="width:128px; text-align:center"> <a href="#" class="menu">Giới thiệu Công ty</a> 
					</td>
					<td style="width:149px;text-align:center"> <a href="#" class="menu">Công Ty Hợp tác</a></td>
					<td style="width:155px;text-align:center"> <a href="#" class="menu">Hệ Thống Phân phối</a></td>
					<td style="width:77px;text-align:center"> <a href="#" class="menu">Món Ăn</a></td>
					<td style="width:101px;text-align:center"> <a href="#" class="menu">Liên Hệ</a></td>
				</tr>
			</table>
			</td>
	</tr>
</table>
